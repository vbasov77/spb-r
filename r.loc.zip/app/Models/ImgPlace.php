<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ImgPlace extends Model
{
    protected $table = 'img_places';
    public $timestamps = false;
}
