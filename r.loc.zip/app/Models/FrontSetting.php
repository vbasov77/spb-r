<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FrontSetting extends Model
{
    protected $table = 'front_settings';
    public $timestamps = false;
}
