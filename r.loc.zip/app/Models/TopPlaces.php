<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopPlaces extends Model
{
    protected $table = 'top_places';
    public $timestamps = false;
}
