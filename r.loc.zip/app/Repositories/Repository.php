<?php


namespace App\Repositories;


abstract class Repository
{

}