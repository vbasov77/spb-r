<?php


namespace App\Services;


class KeyService extends Service
{
    public function keyPublicQiwi(): string
    {
        $key = "48e7qUxn9T7RyYE1MVZswX1FRSbE6iyCj2gCRwwF3Dnh5XrasNTx3BGPiMsyXQFNKQhvukniQG8RTVhYm3iPxfuxSZRKFCvBHcYF51GY86UVB9M7J679s2wmy2oLq9weuHg6JBe7aQ4ajx1CWcG8Arhiypgiq3WC149s3zQc17EnfKt4kvn2esBP4Q5eK";
        return $key;
    }

}