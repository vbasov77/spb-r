
messenger === "WhatsApp" ?  document.getElementById('WhatsApp').checked = true :
    document.getElementById("Telegram").checked = true;