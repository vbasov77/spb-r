$(window).on('load', function () {
    $('#slider3').nivoSlider({

        pauseTime: 7000,
        effect: 'fade',
    });
});
