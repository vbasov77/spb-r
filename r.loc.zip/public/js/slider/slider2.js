$(window).on('load', function () {
    $('#slider2').nivoSlider({

        pauseTime: 7000,
        effect: 'fade',
    });
});
