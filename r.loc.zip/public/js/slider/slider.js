$(window).on('load', function () {
    $('#slider').nivoSlider({

        pauseTime: 7000,
        effect: 'fade',
    });
});
