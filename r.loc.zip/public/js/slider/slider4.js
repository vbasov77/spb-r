
$(window).on('load', function () {
    $('#slider4').nivoSlider({

        pauseTime: 7000,
        effect: 'fade',
    });
});
