var input = document.getElementById('input-id');
var datepicker = new HotelDatepicker(input, {
    startDate: today_is,
});
