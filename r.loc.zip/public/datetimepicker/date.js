jQuery.datetimepicker.setLocale('ru');
jQuery('#datetimepicker').datetimepicker({
    timepicker:false,
    format:'d.m.Y',
    minDate: new Date(),
    dayOfWeekStart: 1,
});

