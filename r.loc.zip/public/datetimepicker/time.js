

jQuery('#datetimepicker').datetimepicker({

    datepicker:false,
    format:'H:i',
    inline:true,
    minTime:'9:00',
    maxTime:'19:00',
});

