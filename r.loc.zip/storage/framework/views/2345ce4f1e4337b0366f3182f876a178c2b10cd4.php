
<?php $__env->startSection('content'); ?>
    <center><h1 style="margin: 60px 0 40px 0">News</h1></center>
    <style>
        a.link {
            color: black;
            text-decoration: none;
        }

        a.link:hover h4 {
            opacity: 1;
        }

        img.rightM {
            float: right;
            width: 150px;
            height: 150px;

        }

        @media  screen and (max-width: 640px) {
            .col-md-9 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            img.rightM {
                width: 100%;
                margin-bottom: 20px;
            }

        }

        .page-item.active .page-link {
            background-color: #fd7e14;
            border-color: #fd7e14;
        }

    </style>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div id="col-md" class="col-md-9">
                <?php if(count($news)): ?>
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $img = json_decode($item->img)
                        ?>

                        <div class="card" style="margin-top: 25px;">
                            <div class="card-body" style="text-align: left;">
                                <a class="link" style="text-decoration: none"
                                   href="<?php echo e(route('post', ["id"=>$item['id']])); ?>">
                                    <?php if(!empty($img[0])): ?>

                                        <img src="<?php echo e($img[0]); ?>"
                                             height="150px" width="auto" class="rightM" style="object-fit: cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>"
                                             height="150px" width="auto"
                                             class="rightM">
                                    <?php endif; ?>
                                    <div class="textBlock">
                                        <?php echo e(mb_substr($item ['text'],  0, 250, 'UTF-8')); ?>...
                                        <br>
                                        <p style="font-size: 10px; margin-top: 20px; float: left"><?php echo e(date('d.m.Y', strtotime($item['created_at']))); ?></p>
                                    </div>
                                    <br>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <?php echo e($news->links()); ?>


                <?php else: ?>
                    Нет материала
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/news/index.blade.php ENDPATH**/ ?>