
<?php $__env->startSection('content'); ?>

    <section>
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h3>Парсер со стен групп.</h3>
                    <p>Файл с id групп создан заранее. После того, как вы нажмёте на кнопку "Парсить"
                        <br>парсер начнёт собирать информацию со стен групп за выбранный период.</p>

                    <form action="<?php echo e(route("admin.parser.store-wallGroupsNews")); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="calendar">Выберете дату:</label><br>
                        <input id="calendar" name="date" class="form-control" type="date" value="<?php echo e($date); ?>"/>
                        <br>
                        <br>
                        <div>
                            <input class="btn btn-outline-success btn-sm" type="submit" value="Парсить">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/parsers/wallGroups.blade.php ENDPATH**/ ?>