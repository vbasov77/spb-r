<li class="has-children">
    <a href="#">Добавить</a>
    <ul class="dropdown">
        <li>
            <a class="dropdown-item" href="<?php echo e(route('create.news')); ?>">Новость</a>
            <a class="dropdown-item" href="<?php echo e(route('admin.create.place')); ?>">Место</a>
            <a class="dropdown-item" href="<?php echo e(route('admin.view_add_order_is_admin')); ?>">Бронь</a>
            <a class="dropdown-item" href="<?php echo e(route('admin.in.queue')); ?>">В очередь</a>
        </li>
    </ul>
</li>
<li>

    <a class="dropdown-item" href="<?php echo e(route('admin.settings')); ?>">Настройки</a>
    <a class="dropdown-item" href="<?php echo e(route('admin.orders')); ?>">Заказы</a>
    <a class="dropdown-item" href="<?php echo e(route('admin.view.queue')); ?>">Очереди</a>
    <a class="dropdown-item" href="<?php echo e(route('admin.reports')); ?>">Отчёты</a>
    <a class="dropdown-item" href="<?php echo e(route('admin.archive')); ?>">Архив</a>
    <a class="dropdown-item" href="<?php echo e(route('admin.del.schedule')); ?>">Очистить базу</a>
    <a class="dropdown-item" href="<?php echo e(route('list.places')); ?>">Куда сходить</a>
    <a class="dropdown-item" href="<?php echo e(route('admin.files')); ?>">Файлы</a>


</li>
<li class="has-children">
    <a href="#">Парсеры</a>
    <ul class="dropdown">
        <li>
            <a class="dropdown-item" href="<?php echo e(route('admin.parser.view-wallGroupsNews')); ?>">Стены групп</a>
        </li>
    </ul>
</li>

<?php /**PATH D:\OpenServer\domains\r.loc\resources\views/blocks/admin_menu.blade.php ENDPATH**/ ?>