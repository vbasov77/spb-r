<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico"/>


    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php if(isset($title)): ?>
            <?php echo e($title); ?> |
        <?php endif; ?>
        <?php echo e(config('app.name')); ?>

    </title>

    <!-- Scripts -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/funder/fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themes/funder/css/style.css')); ?>">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

</head>


<body id="page-top">
<div class="site-wrap">

    <div class="site-mobile-menu">
        <div class="site-mobile-menu-header">
            <div class="site-mobile-menu-close mt-3">
                <span class="icon-close2 js-menu-toggle"></span>
            </div>
        </div>
        <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->

    <div class="site-navbar-wrap js-site-navbar bg-white">

        <div class="container">
            <div class="site-navbar bg-light">

                <div class="row align-items-center">
                    <div class="col-2">
                        <h2 class="mb-0 site-logo"><a style="text-decoration: none;" href="<?php echo e(route('front')); ?>"
                                                      class="font-weight-bold">MIETEN</a>
                        </h2>
                    </div>

                    <div class="col-10">
                        <nav class="site-navigation text-right" role="navigation">
                            <div class="container">
                                <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#"
                                                                                              class="site-menu-toggle js-menu-toggle text-black"><span
                                                class="icon-menu h3"></span></a></div>
                                <ul class="site-menu js-clone-nav d-none d-lg-block">
                                    <?php if(auth()->guard()->guest()): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Логин')); ?></a>
                                        </li>
                                        <?php if(Route::has('register')): ?>
                                            <li class="nav-item">
                                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Регистрация')); ?></a>
                                            </li>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(Auth::user()->isAdmin()): ?>
                                            <li class="has-children">
                                                <a href="#">Админ</a>
                                                <ul class="dropdown arrow-top">
                                                    <?php echo $__env->make('blocks.admin_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </ul>
                                            </li>
                                        <?php endif; ?>
                                        <li class="has-children">
                                            <a href="#"> <?php echo e(Auth::user()->name); ?></a>
                                            <ul class="dropdown arrow-top">
                                                <?php echo $__env->make('blocks.user_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </ul>
                                        </li>

                                    <?php endif; ?>
                                    <li class="active"><a href="<?php echo e(route('front')); ?>"><?php echo e(__('Главная')); ?></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <center>
        <main class="py-4">
            <?php echo $__env->make('components.btn-ap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </center>
</div>
<!-- Footer-->
<footer class="footer bg-black small text-center text-white-50">
    <div class="container px-4 px-lg-5">Апартаменты посуточно &copy; <?php echo e(date('Y')); ?></div>
    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>

</footer>

<script src="<?php echo e(asset('themes/funder/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('themes/funder/js/main.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH D:\OpenServer\domains\r.loc\resources\views/layouts/app.blade.php ENDPATH**/ ?>