<!-- Put this script tag to the <head> of your page -->
<script type="text/javascript" src="https://vk.com/js/api/openapi.js?168"></script>
<center>
    <center><h6 style="margin-bottom: 50px">Будь в курсе! Подпишись на культурные новости Санкт-Петербурга ВКонтакте!</h6></center>

    <!-- Put this div tag to the place, where the Group block will be -->
    <div id="vk_groups"></div>
    <script type="text/javascript">
        VK.Widgets.Group("vk_groups", {
            mode: 1,
            width: 300,
            height: 400,
            color1: "FFFFFF",
            color2: "000000",
            color3: "5181B8"
        }, 7754824);
    </script>
</center><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/blocks/vidgetVk.blade.php ENDPATH**/ ?>