
<?php $__env->startSection('content'); ?>
    <center><h1 style="margin: 60px 0 40px 0">Posts</h1></center>
    <style>
        a.link {
            color: black;
            text-decoration: none;
        }

        a.link:hover h4 {
            opacity: 1;
        }

        img.rightM {
            float: right;
            width: 150px;
            height: 150px;

        }

        @media  screen and (max-width: 640px) {
            .col-md-9 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            img.rightM {
                width: 100%;
                margin-bottom: 20px;
            }

        }

        .page-item.active .page-link {
            background-color: #fd7e14;
            border-color: #fd7e14;
        }

    </style>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div id="col-md" class="col-md-9">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->isAdmin()): ?>
                        <div>
                            <div>
                                <br>
                                <div class="btn btn-outline-danger btn-sm deleteFile" type="submit">Удалить файл
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <br>
                <br>
                <?php if(count($posts)): ?>
                    <br>
                    <br>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" style="margin-top: 25px;">
                            <div class="card-body" style="text-align: left;">
                                <a target="_blank" class="link" style="text-decoration: none"
                                   href="https://vk.com/wall<?php echo e($item['group_id']); ?>_<?php echo e($item['post_id']); ?>">
                                    <b><?php echo e($item['name_group']); ?></b><br><br>
                                    <?php if(!empty($item['url'])): ?>
                                        <img src="<?php echo e($item['url']); ?>"
                                             height="150px" width="auto" class="rightM" style="object-fit: cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>"
                                             height="150px" width="auto"
                                             class="rightM">
                                    <?php endif; ?>
                                    <div class="textBlock">
                                        <?php echo e($item ['text']); ?>...
                                    </div>
                                    <br>
                                    <br>
                                    <div style="font-size: 10px"><?php echo e($item ['date_post']); ?></div>
                                    <img width="20px" height="auto" src="<?php echo e(asset("icons/like.svg")); ?>">
                                    <?php echo e($item ['count_likes']); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    Нет материала
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        var fileName = <?php echo json_encode($fileName, 15, 512) ?>;
    </script>

    <script src="<?php echo e(asset('js/deletes/delete_file.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/parsers/index_wall_gr.blade.php ENDPATH**/ ?>