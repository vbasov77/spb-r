
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('css/gallery.css')); ?>" rel="stylesheet">
    <section>
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center text-center">
                <div class="col-lg-9">
                    <br>
                    <?php echo nl2br(e($post->text)); ?>

                    <br>
                    <?php if(!empty(count($images))): ?>
                        <div class="container page-top">
                            <div class="row justify-content-center text-center">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-4 col-xs-6 thumb">

                                        <img src="<?php echo e($image); ?>"
                                             class="zoom img-fluid " alt="">

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <br>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->isAdmin() || Auth::user()->isModerator()): ?>
                            <div>
                                <div>
                                    <br>
                                    <div class="btn btn-outline-danger btn-sm deletePost" type="submit">Удалить пост
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        

        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                var postId = <?php echo json_encode($post->id, 15, 512) ?>;
            </script>
            <script src="<?php echo e(asset('js/deletes/delete_post_vk.js')); ?>" defer></script>
            <script src="<?php echo e(asset('js/gallery/gallery.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['title' => $post->title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/news/show.blade.php ENDPATH**/ ?>