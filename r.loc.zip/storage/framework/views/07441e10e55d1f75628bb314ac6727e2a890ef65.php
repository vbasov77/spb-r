
<?php $__env->startSection('content'); ?>

    <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
    <style>

        .call-to-action {
            position: relative;
            background-color: #343a40;
            background: url("../assets/img/bg-masthead.jpg") no-repeat center center;
            background-size: cover;
            padding-top: 7rem;
            padding-bottom: 7rem;
        }

        .call-to-action:before {
            content: "";
            position: absolute;
            background-color: #1c375e;
            height: 100%;
            width: 100%;
            top: 0;
            left: 0;
            opacity: 0.5;
        }

        footer.footer {
            padding-top: 4rem;
            padding-bottom: 4rem;
        }

        .line-height {
            line-height: 50px;
        }

        .bg-banner {
            background-color: rgba(0, 0, 0, 0.4);
        }

        .width-adaptive {
            width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .width-adaptive80 {
            width: 80%;
        }

        .width-adaptive60 {
            width: 60%;
        }

        .body-front {

            font-size: 26px;
            color: #7A7A7A;
        }

        iframe {
            width: 98%;
        }

        @media  screen and (max-width: 600px) {
            .body-front {
                font-size: 20px;
            }


            .body-white {
                font-size: 20px;
                color: #fff;
            }

            .width-adaptive {
                width: 100%;
            }

            .width-adaptive80 {
                width: 100%;
            }

            .width-adaptive60 {
                width: 100%;
            }

            .col-lg-6.order-lg-first {
                margin-top: 50px;
            }

            header.masthead {
                padding-top: 3rem;
                padding-bottom: 3rem;
            }

            .front-gif {
                display: none;
            }

            .mob {
                width: 100%;
            }
        }

        main.py-4 {
            padding-top: 0rem !important;
        }

        .preloader {
            height: auto;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-right: -50%;
            transform: translate(-50%, -50%)
        }
    </style>



    <link href="<?php echo e(asset('css/front.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/checkbox/radio.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/pulse_button.css')); ?>" rel="stylesheet">

    <script src="<?php echo e(asset('js/fecha.min.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/hotel-datepicker.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/hotel-datepicker/hotel-datepicker.min.js')); ?>" defer></script>
    <!-- Masthead-->
    <header class="masthead">
        <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
            <div class="bg-banner">
                <div class="d-flex justify-content-center">
                    <div class="text-center">
                        <h1 class="mx-auto mt-2 mb-5" style="color: white">Апартаменты-студия</h1>
                        <h2 class="mx-auto mt-2 mb-5">
                            <div class="body-white">
                                <div class="line-height" style="color: white">
                                    <img width="30px" src="<?php echo e(asset("icons/check.svg")); ?>"> 100 м до набережной Невы<br>
                                    <img width="30px" src="<?php echo e(asset("icons/check.svg")); ?>"> 10 мин пешком до метро<br>

                                    <img width="30px" src="<?php echo e(asset("icons/check.svg")); ?>"> 1 станция метро до центра
                                    СПб<br>
                                    <img width="30px" src="<?php echo e(asset("icons/phone.svg")); ?>"> +7 911 012 09 12<br>
                                </div>
                            </div>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <br><br>
    <!-- About-->
    <section class="about-section text-center marginTop" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <div class="body-front">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isModerator()): ?>
                                <div class="icons">
                                    <a href="<?php echo e(route('create.news')); ?>"> <img style="color: white"
                                                                             src="<?php echo e(asset('icons/post.svg')); ?>"
                                                                             width="50px"
                                                                             height="auto"></a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <br>
                        <?php

                            $firstMonth = explode(",", $dataSettings[0]);
                            $secondMonth = explode(",", $dataSettings[1]);
                        ?>

                        <?php echo $firstMonth[0]; ?>- <?php echo $firstMonth[1]; ?> руб / сут<br>
                        <?php echo $secondMonth[0]; ?>- <?php echo $secondMonth[1]; ?> руб / сут<br>
                        от 5-ти суток<br>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <?php echo $__env->make('components.btn-ap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Projects-->
    <br>
    <br>
    <section class="projects-section bg-light marginTop" id="projects">
        <div class="container px-4 px-lg-5">
            <!-- Featured Project Row-->
            <div class="row gx-0 mb-4 mb-lg-5 align-items-center">
                <div class="col-xl-8 col-lg-7">
                    
                    <div class="width-adaptive80">
                        <div id="carusel" class="carousel slide carousel-fade" data-ride="carousel">
                            <!-- Indicators -->
                            <ul class="carousel-indicators">
                                <li data-target="#carusel" data-slide-to="0" class="active"></li>
                                <li data-target="#carusel" data-slide-to="1"></li>
                                <li data-target="#carusel" data-slide-to="2"></li>

                            </ul>
                            <!-- The slideshow -->
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="<?php echo e(asset('img/slider/1.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/2.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/3.jpg')); ?>" alt="">
                                </div>

                            </div>
                            <a class="carousel-control-prev" href="#carusel" data-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </a>
                            <a class="carousel-control-next" href="#carusel" data-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-5">
                    <div class="featured-text text-center text-lg-center">
                        <div style="text-align: center" class="body-front">
                            <br>
                            <img width="30px" src="<?php echo e(asset("icons/coff.svg")); ?>"> оборудованная кухня<br>
                            <div class="fontawesome"><i class="fas fa-bed"></i> двуспальная кровать<br></div>
                            <div class="fontawesome"><i class="fas fa-snowflake"></i> холодильник<br></div>
                            <div class="fontawesome"><i class="fas fa-tv"></i> телевизор<br></div>
                            <div class="fontawesome"><i class="fas fa-check"></i> утюг<br></div>
                            <div class="fontawesome"><i class="fas fa-fan"></i> фен<br></div>
                        </div>
                    </div>
                </div>
            </div>
            <br>

            <div class="row align-items-center marginTop">
                <div class="col-lg-7">
                    
                    <div class="width-adaptive60" style="float: right">
                        <div id="carusel_8" class="carousel slide carousel-fade" data-ride="carousel">
                            <!-- Indicators -->
                            <ul class="carousel-indicators">
                                <li data-target="#carusel_8" data-slide-to="0" class="active"></li>
                                <li data-target="#carusel_8" data-slide-to="1"></li>
                                <li data-target="#carusel_8" data-slide-to="2"></li>
                                <li data-target="#carusel_8" data-slide-to="3"></li>

                            </ul>
                            <!-- The slideshow -->
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="<?php echo e(asset('img/slider/4.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/5.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/6.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/7.jpg')); ?>" alt="">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carusel_8" data-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </a>
                            <a class="carousel-control-next" href="#carusel_8" data-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 order-lg-first">
                    <div class="featured-text text-center text-lg-left">
                        <div class="body-front">
                            <br>
                            <br>
                            <center><h4>Задать вопрос:</h4></center>
                            <br>
                            <center>
                                <button class="btn btn-outline-success"
                                        onclick="window.location.href = 'https://wa.clck.bar/79110120912';">
                                    <i class="fab fa-whatsapp"></i> по WhatsApp
                                </button>
                            </center>
                            <br>
                            <center>
                                <button class="btn btn-outline-primary"
                                        onclick="window.location.href = 'tel:+79110120912';"><i
                                            class="fas fa-phone-alt"></i> по телефону
                                </button>
                            </center>
                            <br>
                            <br>
                        </div>
                    </div>
                </div>
            </div>

            <br>
            <br>
            <!-- Project One Row-->
            <div class="marginTop">
                <form action="<?php echo e(route("add.dates")); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <center><h4 class="marginTop">Забронировать квартиру</h4></center>
                    <br>
                    <div style="color: red">
                        <center><i> Узнать точную цену на свои даты. Начните бронировать...</i></center>
                    </div>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['type' => 'danger','message' => $error]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <br>
                    <div class="row gx-0 mb-5 mb-lg-0">
                        <div class="col-lg-6">
                            <div id="info"></div>
                            <div>
                                <label for="date_book"><b>Выберете дату:</b></label>
                                <input id="input-id" style="display:inline" name="date_book" type="text"
                                       class="form-control <?php $__errorArgs = ["user_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="Нажмите для выбора даты" autocomplete="off" readonly="readonly"
                                       required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <br>
                            <div class="featured-text text-center text-lg-left">
                                <b>Количество гостей:</b><br>
                                <div class='form_radio_btn2 my_mobile' style="text-align: center;">
                                    <input type='radio' id="initial1" name="guests" value="1" required
                                    ><label for='initial1'>1 гость</label></div>

                                <div class='form_radio_btn2 my_mobile' style="text-align: center;">
                                    <input type='radio' id="initial2" name="guests" value="2" required
                                    ><label for='initial2'>2 гостя</label></div>

                                <br>
                                <br>
                                <div>
                                    <input class="btn btn-outline-primary" id="calendar" type="submit"
                                           value="Продолжить">
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
            <br>
            <!-- Project Two Row-->
            <center><h4 class="marginTop">Местоположение</h4></center>
            <br>
            <div class="row gx-0 justify-content-center">
                <div class="col-lg-6">
                    
                    <img src="<?php echo e(asset('img/map.jpg')); ?>" width="100%" height="auto" alt="">
                    
                    
                    
                </div>
                <div class="col-lg-6 order-lg-first">
                    
                    <div class="d-flex h-100">
                        <div class="project-text w-100 my-auto text-left text-lg-left">
                            <div class="body-front">
                                К вашему вниманию предлагаются уютные апартаменты в трёхзвёздочном отеле, расположенном
                                в непосредственной близости от станции метро «Елизаровская» (всего 10 минут пешком).
                                Отель находится по адресу проспект Обуховской обороны, дом 123а. В непосредственной
                                близости от отеля расположены кафе, рестораны, а также супермаркеты «Магнит», «Дикси» и
                                «Красное & Белое».
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <br>
            <div class="row gx-0 mb-4 mb-lg-5 align-items-center marginTop">
                <div class="col-xl-8 col-lg-7">
                    
                    <div class="width-adaptive80">
                        <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
                            <!-- Indicators -->
                            <ul class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                                <li data-target="#myCarousel" data-slide-to="2"></li>
                            </ul>
                            <!-- The slideshow -->
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="<?php echo e(asset('img/slider/l1.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/l2.jpg')); ?>" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('img/slider/l3.jpg')); ?>" alt="">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </a>
                            <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-5">
                    <div class="featured-text text-center text-lg-left">
                        
                        <br>
                        <br>
                        <center><h4>Задать вопрос:</h4></center>
                        <br>
                        <center>
                            <button class="btn btn-outline-success"
                                    onclick="window.location.href = 'https://wa.clck.bar/79110120912';">
                                <i
                                        class="fab fa-whatsapp"></i> в WhatsApp
                            </button>
                        </center>
                        <br>
                        <center>
                            <button class="btn btn-outline-primary"
                                    onclick="window.location.href = 'tel:+79110120912';"><i
                                        class="fas fa-phone-alt"></i> по телефону
                            </button>
                        </center>
                        <br>

                    </div>
                </div>
            </div>
            <center><h4 class="marginTop">Достопримечательности</h4></center>
            <br>
            <div class="row gx-0 justify-content-center">
                <div class="col-lg-6">
                    
                    <div id="carusel_2" class="carousel slide carousel-fade" data-ride="carousel">
                        <!-- Indicators -->
                        <ul class="carousel-indicators">
                            <li data-target="#carusel_2" data-slide-to="0" class="active"></li>
                            <li data-target="#carusel_2" data-slide-to="1"></li>
                            <li data-target="#carusel_2" data-slide-to="2"></li>
                            <li data-target="#carusel_2" data-slide-to="3"></li>
                            <li data-target="#carusel_2" data-slide-to="4"></li>
                            <li data-target="#carusel_2" data-slide-to="5"></li>
                            <li data-target="#carusel_2" data-slide-to="6"></li>
                            <li data-target="#carusel_2" data-slide-to="7"></li>
                        </ul>
                        <!-- The slideshow -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="<?php echo e(asset('img/slider/b1.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b2.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b3.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b4.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b5.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b6.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b7.jpg')); ?>" alt="">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo e(asset('img/slider/b8.jpg')); ?>" alt="">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carusel_2" data-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </a>
                        <a class="carousel-control-next" href="#carusel_2" data-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 order-lg-first">
                    
                    <div class="d-flex h-100">

                        <div style="float: left" class="body-front">
                            <em>Одна станция метро:</em> <br><img style="width: 30px; opacity: .6"
                                                                  src="<?php echo e(asset('img/metro.svg')); ?>" alt="">
                            <strong>Площадь Александра Невского</strong>:
                            Свято-Троицкая
                            Александро-Невская лавра.<br>
                            <em>Две станции</em>: <strong><img style="width: 30px; opacity: .6"
                                                               src="<?php echo e(asset('img/metro.svg')); ?>">
                                Маяковская, <img style="width: 30px; opacity: .6" src="<?php echo e(asset('img/metro.svg')); ?>"
                                                 alt=""> Площадь Восстания</strong>: ТРЦ Галерея,
                            БКЗ
                            Октябрьский.<br>
                            <em>Три станции</em>: <strong><img style="width: 30px; opacity: .6"
                                                               src="<?php echo e(asset('img/metro.svg')); ?>" alt="">
                                Гостинный Двор</strong>: Казанский Собор, Спас на
                            Крови,
                            Гостинный Двор, Эрмитаж.
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <center><h4 class="marginTop">Смотреть видео</h4></center>
            <br>
















        </div>
    </section>
    <section class="about-section marginTop" id="about">
        <div class="container">
            <br>
            <div class="row gx-0 justify-content-center">
                <div class="col-lg-8 one">
                    <div class="d-flex h-100">
                        <div class="body-front i_am">
                            Приветствую!<br>
                            Я НЕ агент, я собственник.<br> Давайте знакомиться! Меня зовут Виталий😊<br>
                            Мой аккаунт в <i class="fab fa-vk"></i>(
                            <a href="https://vk.com/id642803932" target="_blank">Здесь</a>).
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 two justify-content-center ">
                    <div class="i_am">
                        <img src="<?php echo e(asset('img/ljbqpfwXe0A.png')); ?>">
                    </div>
                </div>
            </div>
            <br>
            <br>
            <center><h4 class="marginTop">Задать вопрос:</h4></center>
            <br>
            <center>
                <button class="btn btn-outline-success"
                        onclick="window.location.href = 'https://wa.clck.bar/79110120912';">
                    <i class="fab fa-whatsapp"></i> в WhatsApp
                </button>
            </center>
            <br>
            <center>
                <button class="btn btn-outline-primary" onclick="window.location.href = 'tel:+79110120912';"><i
                            class="fas fa-phone-alt"></i> по телефону
                </button>
            </center>
            <br>
            <br>
        </div>
    </section>

    <?php echo $__env->make('blocks.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <br>
    <!-- Put this script tag to the <head> of your page -->

    <?php echo $__env->make('blocks.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('blocks.vidgetVk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/preloader/preloader.js')); ?>"></script>
    <script>
        var datebook = <?php echo json_encode($data['date_book'], 15, 512) ?>;
    </script>

    <script src="<?php echo e(asset('js/buttons/close_button.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/close/close.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/calendar.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/front.blade.php ENDPATH**/ ?>