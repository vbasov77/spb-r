
<?php $__env->startSection('content'); ?>
    <style>
        .card.text-center {
            padding: 15px;
            margin: 15px;
        }
    </style>
    <!--    --><?php
    //
    //    var_dump($data ['book']);
    //    return;
    //    ?>

    <div class="container mt-5 mb-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-lg-8">
                <h4>Мои бронирования</h4>
                <?php if(!empty(count($data))): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card text-center" style="margin: 15px">
                            <div class="card-header">
                                <?php echo e($value ['no_in']); ?> - <?php echo e($value['no_out']); ?>

                            </div>
                            <?php
                            $res = explode(',', $value['user_info'])
                            ?>

                            <div class="card-body">
                                №: <?php echo e($value['id']); ?> <br>
                                ФИО: <?php echo e($res[1]); ?> <br>
                                Сумма: <?php echo e($value ['total']); ?> <br><br>
                            </div>

                            <div class="card-footer text-muted">
                                <?php if(!empty($value['confirmed']) == 0): ?>
                                    Статус: Не подтверждён <br>
                                <?php else: ?>
                                    Статус: Подтверждён <br>
                                <?php endif; ?>
                                <br>
                                <a onClick="return confirm('Подтвердите удаление! :(( Если была внесена предоплата, она не возвращается...')"
                                   href="<?php echo e(route('order.delete', ['id' => $value['id']])); ?>" type='button'
                                   style="margin: 10px"
                                   class='btn btn-outline-danger btn-sm'>Отменить</a>
                                <br>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    Бронирования не найдены...
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\r.loc\resources\views/profile.blade.php ENDPATH**/ ?>