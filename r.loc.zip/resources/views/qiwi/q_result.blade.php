@extends('layouts.app')
@section('content')


    <div class="container">
        <h1>Спасибо за бронирование!</h1>
        <font color='#99b1c6'><i class="fas fa-cat fa-5x"></i></font>
    </div>


@endsection
