<style>
    @media (max-width: 500px) {
        .pulse-button {
            width: 60px;
            height: 60px;
            left: 10px;
        }
    }
</style>

<button onclick="window.location.href = 'https://t.me/var_damp';" style="bottom: 50px; background: #0d6efd;"
        class="pulse-button">
    <span style="background: url('icons/telegram.svg') center center no-repeat;" class="pulse-button__icon"></span>
    <span class="pulse-button__text">Telegram</span>
    <span style="border: 1px solid #0d6efd;" class="pulse-button__rings"></span>
    <span style="border: 1px solid #0d6efd;" class="pulse-button__rings"></span>
    <span style="border: 1px solid #0d6efd;" class="pulse-button__rings"></span>

</button>

<button onclick="window.location.href = 'https://wa.clck.bar/79110120912';" style="bottom: 130px; background: #198754;"
        class="pulse-button">
    <span style="background: url('icons/watsappW.svg') center center no-repeat;" class="pulse-button__icon"></span>
    <span class="pulse-button__text">WhatsAap</span>
    <span style="border: 1px solid #198754;" class="pulse-button__rings"></span>
    <span style="border: 1px solid #198754;" class="pulse-button__rings"></span>
    <span style="border: 1px solid #198754;" class="pulse-button__rings"></span>
</button>