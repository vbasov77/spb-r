@extends('layouts.app')
@section('content')

    <div class="container">
        <center>
            <div style="font-size: 150px; opacity: .8; color: #2fa360">
                <img src="{{asset("/images/icons/sad.ico")}}">
            </div>
            <div style="margin-top: 40px">
            <h3>Извините, онлайн оплата временно отключена. <br>
                </h3>
    </div>
        </center>
        <br>
        <br>



    </div>


@endsection
