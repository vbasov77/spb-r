
Оплата по номеру заказа {{$data ['bill'] ['comment']}} произведена. <br>
Сумма оплаты: {{$data ['bill'] ['amount']['value']}}


<br><br>
С уважением,
администрация сайта {{config('app.name')}}!