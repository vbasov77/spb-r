Здравствуйте, админ!<br><br>

Бронирование было УДАЛЕНО ПОЛЬЗОВАТЕЛЕМ...<br><br>

<b>Данные бронирования:</b><br>
{{ $data['user_name']}}<br>
Номер заказа: {{$data['id_book']}}<br>
{{$data['phone']}}<br>
{{$data['email']}}<br>
{{$data['no_in']}} - {{$data['no_out']}}<br>
{{$data['comment']}}<br>
{{$data['user_info']}}<br>
{{$data['total']}}<br>
{{$data['pay']}}<br>
{{$data['info_pay']}}
<br>
<br>
Это письмо было сгенерированот автоматически, пожалуйста, не отвечайте на него!<br><br>
С уважением,
администрация сайта {{config('app.name')}}!



